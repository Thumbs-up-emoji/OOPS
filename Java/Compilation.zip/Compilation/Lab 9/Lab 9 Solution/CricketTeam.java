public class CricketTeam extends Team<CricketPlayer> {
    public CricketTeam(String name, int teamSize, int numMatches) {
        super(name, teamSize, numMatches);
    }
}