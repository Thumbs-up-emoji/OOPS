
public enum Ordering {
	NONE, ASC, DESC, PRIQASC, PRIQDESC, BST
}
