public class CricketPlayer extends Player {

    public CricketPlayer(String name, int numMatches) {
        super(name, numMatches);
    }
}