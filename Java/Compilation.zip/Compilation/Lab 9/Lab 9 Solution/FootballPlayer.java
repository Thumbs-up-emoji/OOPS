public class FootballPlayer extends Player {

    public FootballPlayer(String name, int score) {
        super(name, score);
    }
}