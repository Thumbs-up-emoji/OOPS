public class FootballTeam extends Team<FootballPlayer> {
    public FootballTeam(String name, int teamSize, int numMatches) {
        super(name, teamSize, numMatches);
    }

}